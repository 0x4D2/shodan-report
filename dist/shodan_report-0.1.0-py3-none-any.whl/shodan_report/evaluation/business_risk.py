from enum import Enum


class BusinessRisk(Enum):
    CRITICAL = "critical"
    ATTENTION = "attention"
    MONITOR = "monitor"
