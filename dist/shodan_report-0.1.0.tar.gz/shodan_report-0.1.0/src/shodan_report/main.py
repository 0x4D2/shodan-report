#!/usr/bin/env python3
"""Main entry point - Delegiert an CLI."""

from shodan_report.cli import main

if __name__ == "__main__":
    main()
